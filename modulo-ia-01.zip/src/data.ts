import { Testimonial, FaqItem } from "./types";

export const testimonials: Testimonial[] = [
  {
    id: 1,
    name: "Cesar Gabriel",
    role: "Especialista em Marketing",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150&h=150",
    content: "Fazia semanas que eu não postava com consistência no meu perfil. Depois de usar o Método, criei uma linha editorial completa de 30 dias em menos de 1 hora. O resultado? Mais de 12 novos clientes vindo direto do direct querendo comprar meu serviço de mentoria de alto ticket.",
    niche: "Marketing Digital",
    metric: "+12 Clientes direct"
  },
  {
    id: 2,
    name: "Dra. Amanda Costa",
    role: "Nutricionista Clínica",
    avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=150&h=150",
    content: "Eu odiava escrever legendas, passava horas e o resultado era frio. Agora eu só coloco meu tema e os prompts fazem todo o trabalho de copy de forma extremamente humana. Meu alcance triplicou e fechei 4 novos acompanhamentos individuais em uma única semana.",
    niche: "Saúde & Estética",
    metric: "3x mais Alcance"
  },
  {
    id: 3,
    name: "Rodrigo Mendes",
    role: "Proprietário de E-commerce",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=150&h=150",
    content: "O calendário estratégico me salvou. As ideias de carrossel engajam demais e o gancho realmente segura as pessoas lendo os slides até o final. Tivemos um aumento de 47% nas vendas de coleções novas aplicando os roteiros específicos de Reels.",
    niche: "E-commerce & Moda",
    metric: "+47% Faturamento"
  },
  {
    id: 4,
    name: "Mariana Souza",
    role: "Psicóloga Clinica",
    avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=150&h=150",
    content: "Sempre tive receio de usar Inteligência Artificial por parecer muito robotizado. Mas a engenharia desses prompts realmente gera textos acolhedores, profundos e éticos, conectando de verdade com as dores do meu paciente ideal. Recomendo fortemente a todos!",
    niche: "Profissional Liberal",
    metric: "Recorde de Consultas"
  },
  {
    id: 5,
    name: "Felipe Rocha",
    role: "Personal Trainer",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=150&h=150",
    content: "Eu passava os finais de semana inteiros tentando gravar e escrever posts para captar alunos de consultoria online. Com o Método MCI, agora eu gero roteiros de Reels magnéticos e carrosséis informativos em minutos. Minha agenda de consultoria online lotou em menos de 15 dias de aplicação.",
    niche: "Saúde & Estética",
    metric: "Agenda Lotada"
  },
  {
    id: 6,
    name: "Camila Vasconcelos",
    role: "Arquiteta e Designer de Interiores",
    avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=150&h=150",
    content: "Meu maior desafio no Instagram era transformar curtidas em orçamentos fechados. Os prompts de quebra de objeções e chamadas para ação (CTA) do Método mudaram totalmente o jogo. Consegui fechar 3 novos projetos de alto padrão em um mês apenas mudando o tom da minha comunicação de técnico para magnético.",
    niche: "Profissional Liberal",
    metric: "+3 Projetos Premium"
  },
  {
    id: 7,
    name: "Bruno Santos",
    role: "Mentor de Negócios e Infoprodutor",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=150&h=150",
    content: "Eu já gerenciava uma equipe de conteúdo, mas os custos eram altos e o tempo de aprovação era lento. Implementamos o pacote de prompts do Método Conteúdo Inteligente e nossa velocidade de produção disparou 10 vezes. Economizamos milhares de reais e nossa taxa de conversão cresceu de forma absurda.",
    niche: "Marketing Digital",
    metric: "+R$ 23k em Vendas"
  },
  {
    id: 8,
    name: "Dra. Juliana Lima",
    role: "Advogada Especialista em Família",
    avatar: "https://images.unsplash.com/photo-1567532939604-b6b5b0db2604?auto=format&fit=crop&q=80&w=150&h=150",
    content: "Como advogada, eu tinha muito medo de ser muito informal ou violar regras de publicidade. Mas os prompts são tão inteligentes que geram conteúdos educativos profundos e sérios, mas que ao mesmo tempo conversam perfeitamente com as dores dos meus clientes ideais. Tivemos um boom de novos contatos qualificados no WhatsApp.",
    niche: "Profissional Liberal",
    metric: "+150% Leads Zap"
  }
];

export const faqItems: FaqItem[] = [
  {
    id: 1,
    question: "O que é o Método Conteúdo Inteligente?",
    answer: "É um sistema completo e estratégico de criação de conteúdo validado, focado em atração e conversão de clientes. Ele une um guia de copywriting de alta conversão, um cronograma tático de 30 dias e 20 Prompts Elite meticulosamente programados para fazer com que as Inteligências Artificiais criem postagens com tom humano, magnético e persuasivo em poucos segundos."
  },
  {
    id: 2,
    question: "Preciso saber muito sobre Inteligência Artificial ou ChatGPT?",
    answer: "De forma alguma! O método foi desenvolvido do absoluto zero para pessoas comuns. Nós entregamos os comandos exatos (Prompts de Elite) já testados e validados. Você só precisa copiar o prompt, colar na IA gratuita de sua preferência (ChatGPT, Claude ou Gemini), preencher as lacunas do seu nicho e assistir à mágica acontecer instantaneamente."
  },
  {
    id: 3,
    question: "Serve para iniciantes ou perfis com poucos seguidores?",
    answer: "Sim, com certeza! O método é especialmente poderoso para quem está começando ou tem poucos seguidores. Em vez de focar em posts vazios para ganhar curtidas sem valor de clientes frios, o método ensina a estruturar conteúdos focados em funil de vendas, despertando o desejo imediato de compra em quem já te acompanha, transformando seguidores em clientes pagantes."
  },
  {
    id: 4,
    question: "Funciona para o meu nicho de atuação?",
    answer: "Sim, perfeitamente! Os prompts foram construídos sobre gatilhos psicológicos universais de dor, desejo e urgência. Ele se adapta de forma impecável para médicos, nutricionistas, psicólogos, advogados, contadores, arquitetos, infoprodutores, mentores, afiliados, proprietários de e-commerce, profissionais de estética e negócios locais."
  },
  {
    id: 5,
    question: "Consigo aplicar tudo pelo celular?",
    answer: "Sim! A área de membros premium e todo o material foram otimizados para smartphones. Você pode acessar a plataforma pelo seu celular, copiar os prompts desejados e executá-los diretamente no aplicativo do ChatGPT de onde você estiver, com total facilidade e rapidez."
  },
  {
    id: 6,
    question: "Como vou receber o material do Método?",
    answer: "O envio é 100% imediato e automatizado! Assim que o pagamento de apenas R$ 29,90 for confirmado (no Pix ou Cartão de Crédito é aprovado na mesma hora), você receberá um e-mail oficial enviado pela Kiwify contendo o seu link de login e senha exclusivos para acessar nossa área de membros VIP."
  },
  {
    id: 7,
    question: "Preciso pagar alguma mensalidade ou assinatura recorrente?",
    answer: "Não! O pagamento é único e dá direito a acesso vitalício. Você investe apenas R$ 29,90 hoje e garante o acesso para sempre, com direito a todas as atualizações adicionais que adicionarmos na plataforma sem gastar nenhum centavo a mais."
  },
  {
    id: 8,
    question: "Como funciona a garantia de 7 dias?",
    answer: "Sua compra é totalmente livre de riscos. Se você garantir seu acesso hoje e, em até 7 dias, achar que o material não entregou o valor prometido ou simplesmente não gostar da formatação, basta solicitar o reembolso na própria Kiwify ou nos mandar um e-mail. Devolvemos 100% do seu dinheiro sem perguntas, sem letras miúdas e sem qualquer ressentimento."
  }
];
